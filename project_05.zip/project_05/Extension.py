#Mahdeen Ahmed Khan Sameer
#Spring 2022 CS152
#Project 5


#IDXCalvingInterval = 0 # put this at the top of your code
#parameters[IDXCalvingInterval] # use it like this

import random
import sys

IDXcalvInt = 0
IDXpercentDart = 1
IDXjuvAge = 2
IDXmaxAge = 3
IDXcalfProbSurv = 4
IDXadultProbSurv = 5
IDXseniorProbSurv = 6
IDXcarCapacity = 7
IDXyears = 8
	
IDXGender = 0
IDXAge = 1
IDXMonthsPregnant = 2
IDXMonthsContraceptiveRemaining = 3
	
def newElephant( parameters, age ):
	'''create and return a list with all of the necessary features of an individual elephant'''
	gender = random.choice( ['m' , 'f'])
	monthsPregnant = 0
	monthsContraceptiveRemaining = 0
	
	if gender == 'f':
		if age > parameters[IDXjuvAge] and age <= parameters[IDXmaxAge]:
			if random.random() < 1.0 / parameters[IDXcalvInt]:
				monthsPregnant = random.randint(1, 22)
		
	elephant = [ 0, 0, 0 , 0]
	
	elephant[IDXGender] = gender
	elephant[IDXAge] = age
	elephant[IDXMonthsPregnant] = monthsPregnant
	elephant[IDXMonthsContraceptiveRemaining] = monthsContraceptiveRemaining
	
	return elephant	
	
	
def initPopulation(parameters):
	'''takes in the parameter list and return a list of new elephants'''
	population = []
	for t in range(parameters[IDXcarCapacity]):
		population.append(newElephant(parameters, random.randint(1, parameters[IDXmaxAge])))
	return population
	
	
def incrementAge(population):
	''' This function should take in a population list and return a population list, 
	increasing each elephant's age by 1 (year).'''
	for t in population:
		t[IDXAge] +=1
	return population
	
	
def calcSurvival(parameters, population):
	'''goes through the elephant population list and determines whether each individual
	 elephant survives to the next year'''
	new_population = []
	for elephant in population:
		if elephant[IDXAge] == 1:
			if random.random() < parameters[IDXcalfProbSurv]:
				new_population.append(elephant)
		elif elephant[IDXAge] <= parameters[IDXmaxAge]:
			if random.random() < parameters[IDXadultProbSurv]:
				new_population.append(elephant)
		else: 
			if random.random() < parameters[IDXseniorProbSurv]:
				new_population.append(elephant)
	return new_population
				
		
def dartElephants(parameters, population):
	'''this function goes through the adult females and randomly selects individuals for darting 
	based on the dart probability parameter'''
	maxAge = parameters[IDXmaxAge]
	juvAge = parameters[IDXjuvAge]
	percentDart = parameters[IDXpercentDart]
	for elephant in population:
		if elephant[IDXGender] == 'f' and elephant[IDXAge] > juvAge and elephant[IDXAge] <= maxAge :
			if random.random() < percentDart:
				elephant[IDXMonthsPregnant] = 0
				elephant[IDXMonthsContraceptiveRemaining] = 22
	return population
	
	
def cullElephants(parameters, population):
	'''checks if there are more elephants than the carrying capacity'''
	carryingCap = parameters[IDXcarCapacity]
	totalCulled = len(population) - carryingCap
	if totalCulled	> 0 :
		random.shuffle(population)
		population = population[:carryingCap]		#this is the appropriate list slice indexing because it keeps 
													#all elements from the beginning of the list till the carrying capacity index
	return (population, totalCulled)
	
def controlPopulation(parameters, population):
	'''determines whether the population should be darted or culled and calls the appropriate function'''	
	if parameters[IDXpercentDart] == 0:
		(new_population, numCulled) = cullElephants( parameters, population )
	else:
		new_population = dartElephants( parameters, population )
		numCulled = 0
	return (new_population, numCulled)
	

def simulateMonth(parameters, population):
	'''moves the simulation forward by one month.'''
	maxAge = parameters[IDXmaxAge]
	juvAge = parameters[IDXjuvAge]
	calvInt = parameters[IDXcalvInt]

	for elephant in population:
		gender = elephant[IDXGender]
		age = elephant[IDXAge]
		monthsPregnant = elephant[IDXMonthsPregnant]
		monthsContraceptive = elephant[IDXMonthsContraceptiveRemaining]

		if gender == 'f' and age > juvAge and age <= maxAge:
			if monthsContraceptive > 0:
				elephant[IDXMonthsContraceptiveRemaining] -= 1
			elif monthsPregnant > 0:
				if monthsPregnant >= 22:
					population.append(newElephant(parameters, 1))
					elephant[IDXMonthsPregnant] = 0
				else:
					elephant[IDXMonthsPregnant] += 1
			else:
				if age > parameters[IDXjuvAge] and age <= parameters[IDXmaxAge]:
					if random.random() < 1.0 / (3.1*12 - 22):
						elephant[IDXMonthsPregnant] = 1
					monthsPregnant = 1
	return population


def simulateYear(parameters, population):
	'''moves the simulation forward by one month.'''
	population = calcSurvival(parameters, population)
	population = incrementAge(population)
	for y in range(12):
		population = simulateMonth(parameters, population)

	return population
	
def calcResults(parameters, population, numCulled):
	'''calculates how many calves, juveniles, adult males, adult females, and seniors are in the population'''
	maxAge = parameters[IDXmaxAge]
	juvAge = parameters[IDXjuvAge]
	numCalves = 0
	numJuveniles = 0
	numAdultMales = 0
	numAdultFemales = 0
	numSeniors = 0
	numTotal = len(population)
	for elephant in population:
		if elephant[IDXAge] == 1:
			numCalves +=1
		elif elephant[IDXAge] <= juvAge:
			numJuveniles +=1
		elif elephant[IDXAge] <= maxAge:
			if elephant[IDXGender] == 'f':
				numAdultFemales +=1
			elif elephant[IDXGender] == 'm':
				numAdultMales += 1
		else:
			numSeniors += 1
	return (numTotal, numCalves, numJuveniles, numAdultMales, numAdultFemales, numSeniors, numCulled)

def runSimulation(parameters):		#where N is the number of years to run the simulation 
	'''creates the new population, applies any control procedures (e.g. darts them), loops over N years,
	 simulating the year, and it keeps track of the demographics for each year by appending them to a list'''
	popsize = parameters[IDXcarCapacity]

	# init the population
	population = initPopulation( parameters )
	[population, numCulled] = controlPopulation( parameters, population )

	# run the simulation for N years, storing the results
	results = []
	for l in range(parameters[IDXyears]):
		population = simulateYear( parameters, population )
		[population, numCulled] = controlPopulation( parameters, population )
		results.append( calcResults( parameters, population, numCulled ) )
		if results[l][0] > 2 * popsize or results[l][0] == 0 : # cancel early, out of control
			print( 'Terminating early' )
			break
		print("At the end of year %d, the population is %0.3f" % (l, results[-1][0]))
	return results 
	

'''def test():
	# assign each parameter from the table above to a variable with an informative name
	calvInt = 3.1	#Calving Interval
	percentDart = 0.0	#Percent Darted
	juvAge = 12 #Juvenile Age
	maxAge = 60 #Maximum Age
	calfProbSurv = 0.85 #Probability of Calf Survival
	adultProbSurv = 0.996	#Probability of Adult Survival
	seniorProbSurv = 0.20	#Probability of Senior Survival
	carCapacity = 20	#Carrying Capacity 
	years = 200 #Number of Years

	# make the parameter list out of the variables
	parameters = [calvInt, percentDart, juvAge, maxAge, calfProbSurv, adultProbSurv, seniorProbSurv, carCapacity, years]
	
	#indexes of parameters
	

	#print('parameter list = ', parameters)
	
	#testing newElephant function
	pop = []
	for i in range(15):
		pop.append( newElephant( parameters, random.randint(1, parameters[IDXmaxAge]) ) )

	for e in pop:
		print (e)

	#test code for initPopulation()
	pop = initPopulation(parameters)
	print(pop)
	
	#test code for incrementAge
	pop = incrementAge(pop)
	print(pop)
	
	
if __name__ == "__main__":
	test()'''
	
def main(argv):
	'''main function'''
	if len(argv) < 2:
		print("input command line argument")
		exit	#exits in case the length of the command line input is less than 2
		
	probDart = float(argv[1])
	
	calvInt = 3.1	#Calving Interval
	percentDart = probDart
	juvAge = 12 #Juvenile Age
	maxAge = 60 #Maximum Age
	calfProbSurv = 0.85 #Probability of Calf Survival
	adultProbSurv = 0.996	#Probability of Adult Survival
	seniorProbSurv = 0.20	#Probability of Senior Survival
	carCapacity = 7000	#Carrying Capacity 
	years = 200 #Number of Years
	
	
	parameters = [calvInt, percentDart, juvAge, maxAge, calfProbSurv, adultProbSurv, seniorProbSurv, carCapacity, years]
	
	results = runSimulation(parameters)
	
	#calculating averages
	total = 0
	for i in range(len(results)):
		total += results[i][0]
	avgtotal = total / len(results)
	print( 'average total population is', avgtotal)
	
	totalCalves = 0
	for i in range(len(results)):
		totalCalves += results[i][1]
	avgcalves = totalCalves/ len(results)
	print ('average number of elephant calves is' , avgcalves)
	
	totaljuveniles = 0
	for i in range(len(results)):
		totaljuveniles += results[i][2]
	avgjuveniles = totaljuveniles/ len(results)
	print( 'average number of juvenile elephant is' , avgjuveniles)
	
	totaladultmales = 0
	for i in range(len(results)):
		totaladultmales += results[i][4]
	avgadultmales = totaladultmales/ len(results)
	print( 'average number of adultmale elephant is' , avgadultmales)
	
	totaladultfemales = 0
	for i in range(len(results)):
		totaladultfemales += results[i][3]
	avgadultfemales = totaladultfemales/ len(results)
	print ('average number of adultfemales elephant is' , avgadultfemales)
	
	totalseniors = 0
	for i in range(len(results)):
		totalseniors += results[i][4]
	avgseniors = totalseniors/ len(results)
	print( 'average numbers of senior elephant is' , avgseniors)
	
if __name__ == "__main__":
	main(sys.argv)