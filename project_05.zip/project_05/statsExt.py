#Mahdeen Ahmed Khan Sameer
#Spring 2022 CS152
#this file computes statistics

def sum(data):
	theSum = 0.0
	for element in data :
		theSum +=element
	return theSum
	

def min(data):	
	'''function that finds the minimum in a list when called'''
	minimum = 100000000000
	for element in data:
		if element < minimum:
			minimum = element
	return minimum
	
	
def max(data):	
	'''function that finds the maximum in a list when called'''
	maximum = -100000000000
	for element in data:
		if element > maximum:
			maximum = element
	return maximum
		
	
def mean(data):		
	'''function that finds the mean of a list when called'''
	theMean = sum(data)/(len(data))
	return theMean	


def variance(data):
	'''function that finds the variance of a list when called'''
	sumSquaredDiff = 0.0
	for i in data:
		diff = i - mean(data)
		squaredDiff = diff * diff
		sumSquaredDiff += squaredDiff
		sigmaSquared =	sumSquaredDiff/(len(data) - 1)
	return sigmaSquared


def stdDev(data):
	'''function that finds the standard deviation of a list when called'''
	sigma = variance(data)**.5
	return sigma

	
def range(data):
	'''function that finds the range of a list when called'''
	range = len(data)
	return range


def stdError(data):
	'''function that finds the standard error of a list when called'''
	error = (stdDev(data))/(len(data)**.5)
	return error
	
	
def test():
	data = [1, 2, 3, 4]
	q = min(data)
	print("min = %.3f" % q)
	u = max(data)
	print("max = %.3f" % u)
	y = sum(data)
	print ("sum = %.3f" % y)
	n = mean(data)
	print ("mean = %.3f" % n)
	m = variance(data)
	print ("variance = %.3f" % m)
	t = stdDev(data)
	print("standard deviation = %.3f" % t)
	s = range(data)
	print("range =", s)
	v = stdError(data)
	print("standard error = %.3f" % v)
	


if __name__ == "__main__":
	test()
	